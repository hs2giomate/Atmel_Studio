#include <atmel_start.h>

volatile bool flag   = false;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	gpio_set_pin_pull_mode(NMI_BUTTON, GPIO_PULL_UP);

	/* Replace with your application code */
	while (1) {
		if (flag)
		{
			
		}
	}
}
