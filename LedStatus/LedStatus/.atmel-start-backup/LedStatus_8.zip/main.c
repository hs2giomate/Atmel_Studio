#include <atmel_start.h>



int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	gpio_set_pin_pull_mode(NMI, GPIO_PULL_UP);
	

	/* Replace with your application code */
	while (1) {
	
			
		
	}
}
