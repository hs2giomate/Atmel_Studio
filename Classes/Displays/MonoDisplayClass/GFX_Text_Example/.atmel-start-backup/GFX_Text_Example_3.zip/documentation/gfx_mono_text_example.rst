=====================
GFX Mono Text Example
=====================

OLED1 Xplained pro board must be connected to EXT3 extension header for 
SAMD21/R21/DA1/E54/ Xplained Pro boards and to EXT1 extension header 
for SAMV71/E70/G53/G55/ Xplained Pro boards.

This example draws "Hello, world!" on the display.

Drivers
-------
* Synchronous SPI Master
* GPIO

Default interface settings
--------------------------
* SPI Master

  * 50000 baud-rate
  * 8-bit character size
