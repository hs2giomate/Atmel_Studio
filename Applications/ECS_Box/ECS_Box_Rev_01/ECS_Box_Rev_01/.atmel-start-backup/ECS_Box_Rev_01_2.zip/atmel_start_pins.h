/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */
#ifndef ATMEL_START_PINS_H_INCLUDED
#define ATMEL_START_PINS_H_INCLUDED

#include <hal_gpio.h>

// SAME54 has 14 pin functions

#define GPIO_PIN_FUNCTION_A 0
#define GPIO_PIN_FUNCTION_B 1
#define GPIO_PIN_FUNCTION_C 2
#define GPIO_PIN_FUNCTION_D 3
#define GPIO_PIN_FUNCTION_E 4
#define GPIO_PIN_FUNCTION_F 5
#define GPIO_PIN_FUNCTION_G 6
#define GPIO_PIN_FUNCTION_H 7
#define GPIO_PIN_FUNCTION_I 8
#define GPIO_PIN_FUNCTION_J 9
#define GPIO_PIN_FUNCTION_K 10
#define GPIO_PIN_FUNCTION_L 11
#define GPIO_PIN_FUNCTION_M 12
#define GPIO_PIN_FUNCTION_N 13

#define iAlcPressureHi GPIO(GPIO_PORTA, 0)
#define iAlcPressureLo GPIO(GPIO_PORTA, 1)
#define PA22 GPIO(GPIO_PORTA, 22)
#define PA23 GPIO(GPIO_PORTA, 23)
#define PA24 GPIO(GPIO_PORTA, 24)
#define PA25 GPIO(GPIO_PORTA, 25)
#define iAclHeater1StatusChanged GPIO(GPIO_PORTB, 3)
#define niAlcFansStatusChanged GPIO(GPIO_PORTB, 4)
#define iAclCcuStatusChanged GPIO(GPIO_PORTB, 5)
#define niAlcMiscInStatusChanged GPIO(GPIO_PORTB, 6)
#define iAclHeater2StatusChanged GPIO(GPIO_PORTB, 7)
#define iAclFv1StatusChanged GPIO(GPIO_PORTB, 8)
#define iAclScavFanI2cSda GPIO(GPIO_PORTB, 10)
#define iAclScavFanI2cScl GPIO(GPIO_PORTB, 11)
#define niAlcScaFanStatusChanged GPIO(GPIO_PORTB, 14)
#define PB28 GPIO(GPIO_PORTB, 28)
#define PB29 GPIO(GPIO_PORTB, 29)
#define iMaintUsbVbus GPIO(GPIO_PORTC, 0)
#define TIMER GPIO(GPIO_PORTC, 1)
#define iUcNoFailure GPIO(GPIO_PORTC, 2)
#define iMaintUsbId GPIO(GPIO_PORTC, 19)
#define niAmmcSpiSs GPIO(GPIO_PORTC, 25)
#define niAlcTempSensSpiSs2 GPIO(GPIO_PORTC, 26)
#define niAlcTempSensSpiSs1 GPIO(GPIO_PORTC, 27)
#define niAlcTempSensSpiSs0 GPIO(GPIO_PORTC, 28)
#define PD08 GPIO(GPIO_PORTD, 8)
#define PD09 GPIO(GPIO_PORTD, 9)
#define PD10 GPIO(GPIO_PORTD, 10)

#endif // ATMEL_START_PINS_H_INCLUDED
