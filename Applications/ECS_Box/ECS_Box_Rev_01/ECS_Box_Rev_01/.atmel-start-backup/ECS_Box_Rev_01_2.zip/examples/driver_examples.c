/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_examples.h"
#include "driver_init.h"
#include "utils.h"

static void button_on_PB28_pressed(void)
{
}

static void button_on_PB29_pressed(void)
{
}

/**
 * Example of using EXTERNAL_IRQ_0
 */
void EXTERNAL_IRQ_0_example(void)
{

	ext_irq_register(PIN_PB28, button_on_PB28_pressed);
	ext_irq_register(PIN_PB29, button_on_PB29_pressed);
}

static uint8_t I2C_MiscInc_example_str[12] = "Hello World!";

void I2C_MiscInc_tx_complete(struct i2c_m_async_desc *const i2c)
{
}

void I2C_MiscInc_example(void)
{
	struct io_descriptor *I2C_MiscInc_io;

	i2c_m_async_get_io_descriptor(&I2C_MiscInc, &I2C_MiscInc_io);
	i2c_m_async_enable(&I2C_MiscInc);
	i2c_m_async_register_callback(&I2C_MiscInc, I2C_M_ASYNC_TX_COMPLETE, (FUNC_PTR)I2C_MiscInc_tx_complete);
	i2c_m_async_set_slaveaddr(&I2C_MiscInc, 0x12, I2C_M_SEVEN);

	io_write(I2C_MiscInc_io, I2C_MiscInc_example_str, 12);
}

/**
 * Example of using SPI_Alc to write "Hello World" using the IO abstraction.
 */
static uint8_t example_SPI_Alc[12] = "Hello World!";

void SPI_Alc_example(void)
{
	struct io_descriptor *io;
	spi_m_sync_get_io_descriptor(&SPI_Alc, &io);

	spi_m_sync_enable(&SPI_Alc);
	io_write(io, example_SPI_Alc, 12);
}
