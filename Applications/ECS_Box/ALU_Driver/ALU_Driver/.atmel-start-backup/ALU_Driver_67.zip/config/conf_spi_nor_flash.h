/* Auto-generated config file conf_spi_nor_flash.h */
#ifndef CONF_SPI_NOR_FLASH_H
#define CONF_SPI_NOR_FLASH_H

// <<< Use Configuration Wizard in Context Menu >>>

//<o>Quad Mode
//<0=>Disable
//<1=>Enable
//<i>This sets enable/disable quad data mode
//<id>conf_quad_mode
#ifndef CONF_SPI_NOR_FLASH_0_QUAD_MODE
#define CONF_SPI_NOR_FLASH_0_QUAD_MODE 1
#endif

// <<< end of configuration section >>>

#endif // CONF_SPI_NOR_FLASH_H
