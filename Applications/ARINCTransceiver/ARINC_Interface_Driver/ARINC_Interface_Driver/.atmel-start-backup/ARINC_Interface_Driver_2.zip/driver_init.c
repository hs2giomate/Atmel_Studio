/*
 * Code generated from Atmel Start.
 *
 * This file will be overwritten when reconfiguring your Atmel Start project.
 * Please copy examples or other code you want to keep to a separate file
 * to avoid losing it when reconfiguring.
 */

#include "driver_init.h"
#include <peripheral_clk_config.h>
#include <utils.h>
#include <hal_init.h>

void delay_driver_init(void)
{
	delay_init(SysTick);
}

void system_init(void)
{
	init_mcu();

	// GPIO on PB28

	gpio_set_pin_level(SPI1_CS,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   true);

	// Set pin direction to output
	gpio_set_pin_direction(SPI1_CS, GPIO_DIRECTION_OUT);

	gpio_set_pin_function(SPI1_CS, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PC02

	// Set pin direction to input
	gpio_set_pin_direction(OLED_BUTTON2, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(OLED_BUTTON2,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_UP);

	gpio_set_pin_function(OLED_BUTTON2, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PC03

	// Set pin direction to input
	gpio_set_pin_direction(OLED_BUTTON3, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(OLED_BUTTON3,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_UP);

	gpio_set_pin_function(OLED_BUTTON3, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PC30

	// Set pin direction to input
	gpio_set_pin_direction(OLED_BUTTON1, GPIO_DIRECTION_IN);

	gpio_set_pin_pull_mode(OLED_BUTTON1,
	                       // <y> Pull configuration
	                       // <id> pad_pull_config
	                       // <GPIO_PULL_OFF"> Off
	                       // <GPIO_PULL_UP"> Pull-up
	                       // <GPIO_PULL_DOWN"> Pull-down
	                       GPIO_PULL_UP);

	gpio_set_pin_function(OLED_BUTTON1, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PD10

	gpio_set_pin_level(OLED_LED1,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   true);

	// Set pin direction to output
	gpio_set_pin_direction(OLED_LED1, GPIO_DIRECTION_OUT);

	gpio_set_pin_function(OLED_LED1, GPIO_PIN_FUNCTION_OFF);

	// GPIO on PD11

	gpio_set_pin_level(OLED_LED3,
	                   // <y> Initial level
	                   // <id> pad_initial_level
	                   // <false"> Low
	                   // <true"> High
	                   true);

	// Set pin direction to output
	gpio_set_pin_direction(OLED_LED3, GPIO_DIRECTION_OUT);

	gpio_set_pin_function(OLED_LED3, GPIO_PIN_FUNCTION_OFF);

	delay_driver_init();
}
