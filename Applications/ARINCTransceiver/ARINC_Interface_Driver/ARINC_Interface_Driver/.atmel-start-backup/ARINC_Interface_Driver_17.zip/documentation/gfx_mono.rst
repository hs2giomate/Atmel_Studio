GFX Mono
========

GFX Mono driver is a part of the GFX Mono graphics library, it provides means to draw basic shapes such as lines,
rectangles, circles and predefined bitmaps.

There can be any amount of instances of the GFX Mono driver in a system with the limitation by available memory.
Each instance requires an instance of the display driver to operate. Each instance of the GFX Mono driver can work with
only one physical display; if there are two displays, two instances of the GFX Mono driver must exist.
