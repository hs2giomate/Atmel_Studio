/**
 * \file
 *
 * \brief C12832 A1X display related functionality implementation.
 *
 * Copyright (c) 2015-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#include <c12832_a1z.h>
#if CONF_C12832_FRAMEBUFFER == 1
#include <framebuffer.h>
#endif

/**
 * \brief C12832 virtual functions table
 */
static struct display_mono_interface c12832a1z_interface
    = {c12832a1z_get_byte, c12832a1z_put_byte, c12832a1z_put_page, c12832a1z_draw_pixel, c12832a1z_mask_byte};

/**
 * \brief Construct / initialize instance of C12832A1Z display
 */
struct display_mono *c12832a1z_construct(struct display_mono *const me, uint8_t *const framebuffer,
                                         struct io_descriptor *const io, const uint8_t cs, const uint8_t a0,
                                         const uint8_t reset)
{
	struct c12832a1z *display = (struct c12832a1z *)me;

	display_mono_construct(
	    &display->parent, &display->dc.parent, C12832_A1Z_LCD_WIDTH, C12832_A1Z_LCD_HEIGHT, &c12832a1z_interface);
	st7565r_construct(&display->dc.parent, io, cs, a0, reset);

#if CONF_C12832_FRAMEBUFFER == 1
	framebuffer_construct(&display->framebuffer.parent, framebuffer, C12832_A1Z_LCD_WIDTH, C12832_A1Z_LCD_HEIGHT);
#endif

	display_mono_init(me, C12832_A1Z_LCD_WIDTH, C12832_A1Z_LCD_PAGES);

	return me;
}

/**
 * \brief Put framebuffer to the display controller
 */
void c12832a1z_put_framebuffer(const struct display_mono *const me)
{
#if CONF_C12832_FRAMEBUFFER == 1
	const struct c12832a1z *disp = (const struct c12832a1z *)me;

	display_mono_put_framebuffer(
	    &disp->parent, disp->framebuffer.fbpointer, C12832_A1Z_LCD_WIDTH, C12832_A1Z_LCD_PAGES);
#endif
}

/**
 * \brief Put a page from RAM to the display controller.
 */
void c12832a1z_put_page(const struct display_mono *const me, const enum gfx_mono_color *data, const gfx_coord_t page,
                        const gfx_coord_t page_offset, const gfx_coord_t width)
{
	const struct c12832a1z *const disp = (const struct c12832a1z *)me;

#if CONF_C12832_FRAMEBUFFER == 1
	framebuffer_put_page(&disp->framebuffer.parent, data, page, page_offset, width);
#endif
	display_mono_put_page(&disp->parent, data, page, page_offset, width);
}

/**
 * \brief Read a page from the display controller
 */
void c12832a1z_get_page(const struct display_mono *const me, enum gfx_mono_color *data, const gfx_coord_t page,
                        const gfx_coord_t page_offset, const gfx_coord_t width)
{
	const struct c12832a1z *const disp = (const struct c12832a1z *)me;

#ifdef CONFIG_ST7565R_FRAMEBUFFER
	framebuffer_get_page(&disp->framebuffer.parent, data, page, page_offset, width);
#else
	display_mono_get_page(&disp->parent, data, page, page_offset, width);
#endif
}

/**
 * \brief Draw pixel to screen
 */
void c12832a1z_draw_pixel(const struct display_mono *const me, const gfx_coord_t x, const gfx_coord_t y,
                          const enum gfx_mono_color color)
{
	const struct c12832a1z *const disp = (const struct c12832a1z *)me;

	display_mono_draw_pixel(&disp->parent, x, y, color, C12832_A1Z_LCD_WIDTH, C12832_A1Z_LCD_HEIGHT, 8);
}

/**
 * \brief Get the pixel value at x,y
 */
uint8_t c12832a1z_get_pixel(const struct display_mono *const me, const gfx_coord_t x, const gfx_coord_t y)
{
	const struct c12832a1z *const disp = (const struct c12832a1z *)me;

	return display_mono_get_pixel(&disp->parent, x, y, C12832_A1Z_LCD_WIDTH, C12832_A1Z_LCD_HEIGHT, 8);
}

/**
 * \brief Put a byte to the display controller RAM
 */
void c12832a1z_put_byte(const struct display_mono *const me, const gfx_coord_t page, const gfx_coord_t column,
                        const uint8_t data)
{
	const struct c12832a1z *const disp = (const struct c12832a1z *)me;

#if CONF_C12832_FRAMEBUFFER == 1
	framebuffer_put_byte(&disp->framebuffer.parent, page, column, data);
#endif
	display_mono_put_byte(&disp->parent, page, column, data);
}

/**
 * \brief Get a byte from the display controller RAM
 */
uint8_t c12832a1z_get_byte(const struct display_mono *const me, const gfx_coord_t page, const gfx_coord_t column)
{
	const struct c12832a1z *const disp = (const struct c12832a1z *)me;

#if CONF_C12832_FRAMEBUFFER == 1
	return framebuffer_get_byte(&disp->framebuffer.parent, page, column);
#else
	return display_mono_get_byte(&disp->parent, page, column);
#endif
}

/**
 * \brief Read/Modify/Write a byte on the display controller
 */
void c12832a1z_mask_byte(const struct display_mono *const me, const gfx_coord_t page, const gfx_coord_t column,
                         const enum gfx_mono_color pixel_mask, const enum gfx_mono_color color)
{
	const struct c12832a1z *const disp = (const struct c12832a1z *)me;

	display_mono_mask_byte(&disp->parent, page, column, pixel_mask, color);
}
