/**
 * \file
 *
 * \brief ST7565R display controller related functionality implementation.
 *
 * Copyright (c) 2015-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#include <display_ctrl_mono.h>
#include <st7565r.h>
#include <hal_gpio.h>

/**
 * \brief ST7565R virtual functions table
 */
static struct display_ctrl_mono_interface st7565r_interface = {
    st7565r_write_data,
    st7565r_read_data,
    st7565r_set_page_address,
    st7565r_set_column_address,
    st7565r_set_start_line_address,
};

static void st7565r_init(struct display_ctrl_mono *const me);

/**
 * \brief Construct / initialize instance of ST7565R display controller
 */
struct display_ctrl_mono *st7565r_construct(struct display_ctrl_mono *const me, struct io_descriptor *const io,
                                            const uint8_t cs, const uint8_t a0, const uint8_t reset)
{
	struct st7565r *str = (struct st7565r *)me;

	display_ctrl_mono_construct(me, io, &st7565r_interface);

	str->pin_cs    = cs;
	str->pin_a0    = a0;
	str->pin_reset = reset;

	st7565r_init(me);

	return me;
}

/**
 * \brief Write a command to the display controller
 */
void st7565r_write_command(const struct display_ctrl_mono *const me, const uint8_t command)
{
	struct io_descriptor *      io   = me->io;
	const struct st7565r *const ctrl = (const struct st7565r *const)me;

	gpio_set_pin_level(ctrl->pin_a0, false);
	gpio_set_pin_level(ctrl->pin_cs, false);
	io->write(io, &command, 1);
	gpio_set_pin_level(ctrl->pin_cs, true);
}

/**
 * \brief Write data to the display controller
 */
void st7565r_write_data(const struct display_ctrl_mono *const me, const uint8_t data)
{
	struct io_descriptor *      io   = me->io;
	const struct st7565r *const ctrl = (const struct st7565r *const)me;

	gpio_set_pin_level(ctrl->pin_a0, true);
	gpio_set_pin_level(ctrl->pin_cs, false);
	io->write(io, &data, 1);
	gpio_set_pin_level(ctrl->pin_cs, true);
	gpio_set_pin_level(ctrl->pin_a0, false);
}

/**
 * \brief Read data from the display controller
 */
uint8_t st7565r_read_data(const struct display_ctrl_mono *const me)
{
	(void)me;
	return 0;
}

/**
 * \brief Perform a soft reset of the display controller
 */
void st7565r_soft_reset(const struct display_ctrl_mono *const me)
{
	st7565r_write_command(me, ST7565R_CMD_RESET);
}

/**
 * \brief Perform a hard reset of the display controller
 */
void st7565r_hard_reset(const struct display_ctrl_mono *me)
{
	display_ctrl_mono_hard_reset(((struct st7565r *)me)->pin_reset, 10);
}

/**
 * \brief Enable the display sleep mode
 */
void st7565r_enable_sleep(const struct display_ctrl_mono *const me)
{
	st7565r_write_command(me, ST7565R_CMD_SLEEP_MODE);
}

/**
 * \brief Disable the display sleep mode
 */
void st7565r_disable_sleep(const struct display_ctrl_mono *const me)
{
	st7565r_write_command(me, ST7565R_CMD_NORMAL_MODE);
}

/**
 * \brief Set current page in display RAM
 */
void st7565r_set_page_address(const struct display_ctrl_mono *const me, const uint8_t address)
{
	st7565r_write_command(me, ST7565R_CMD_PAGE_ADDRESS_SET(address & 0xF));
}

/**
 * \brief Set current column in display RAM
 */
void st7565r_set_column_address(const struct display_ctrl_mono *const me, uint8_t address)
{
	address &= 0x7F;
	st7565r_write_command(me, ST7565R_CMD_COLUMN_ADDRESS_SET_MSB(address >> 4));
	st7565r_write_command(me, ST7565R_CMD_COLUMN_ADDRESS_SET_LSB(address & 0x0F));
}

/**
 * \brief Set the display start draw line address
 */
void st7565r_set_start_line_address(const struct display_ctrl_mono *const me, const uint8_t address)
{
	st7565r_write_command(me, ST7565R_CMD_START_LINE_SET(address & 0x3F));
}

/**
 * \brief Turn the display display on
 */
void st7565r_on(const struct display_ctrl_mono *const me)
{
	st7565r_write_command(me, ST7565R_CMD_DISPLAY_ON);
}

/**
 * \brief Turn the display display off
 */
void st7565r_off(const struct display_ctrl_mono *const me)
{
	st7565r_write_command(me, ST7565R_CMD_DISPLAY_OFF);
}

/**
 * \brief Initialize the display controller
 *
 * Call this function to initialize the hardware interface and the display
 * controller. When initialization is done the display is turned on and ready
 * to receive data.
 *
 * \param[in] me The pointer to display instance
 */
static void st7565r_init(struct display_ctrl_mono *const me)
{
	struct st7565r *st7565r = (struct st7565r *)me;

	st7565r_hard_reset(me);
	gpio_set_pin_level(st7565r->pin_a0, false);
	st7565r_write_command(me, ST7565R_CMD_ADC_NORMAL);
	st7565r_display_invert_disable(me);
	st7565r_write_command(me, ST7565R_CMD_REVERSE_SCAN_DIRECTION);
	st7565r_write_command(me, ST7565R_CMD_LCD_BIAS_1_DIV_6_DUTY33);
	st7565r_write_command(me, ST7565R_CMD_POWER_CTRL_ALL_ON);
	st7565r_write_command(me, ST7565R_CMD_BOOSTER_RATIO_SET);
	st7565r_write_command(me, ST7565R_CMD_BOOSTER_RATIO_2X_3X_4X);
	st7565r_write_command(me, ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_1);
	st7565r_set_contrast(me, 30);
	st7565r_on(me);
}

/**
 * \brief Set the display contrast level
 */
uint8_t st7565r_set_contrast(const struct display_ctrl_mono *const me, const uint8_t contrast)
{
	st7565r_write_command(me, ST7565R_CMD_ELECTRONIC_VOLUME_MODE_SET);
	st7565r_write_command(me, ST7565R_CMD_ELECTRONIC_VOLUME(contrast));

	return contrast;
}

/**
 * \brief Invert all pixels on the display
 */
void st7565r_display_invert_enable(const struct display_ctrl_mono *const me)
{
	st7565r_write_command(me, ST7565R_CMD_DISPLAY_REVERSE);
}

/**
 * \brief Disable invert of all pixels on the display
 */
void st7565r_display_invert_disable(const struct display_ctrl_mono *const me)
{
	st7565r_write_command(me, ST7565R_CMD_DISPLAY_NORMAL);
}

/**
 * \brief Sets all display pixels on
 */
void st7565r_set_all_pixels(const struct display_ctrl_mono *const me, const bool pixels_on)
{
	if (pixels_on) {
		st7565r_write_command(me, ST7565R_CMD_DISPLAY_ALL_POINTS_ON);
	} else {
		st7565r_write_command(me, ST7565R_CMD_DISPLAY_ALL_POINTS_OFF);
	}
}
