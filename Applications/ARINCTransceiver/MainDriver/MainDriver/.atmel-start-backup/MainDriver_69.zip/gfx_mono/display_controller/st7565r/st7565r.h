/**
 * \file
 *
 * \brief ST7565R display controller related functionality declaration.
 *
 * Copyright (c) 2015-2018 Microchip Technology Inc. and its subsidiaries.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Subject to your compliance with these terms, you may use Microchip
 * software and any derivatives exclusively with Microchip products.
 * It is your responsibility to comply with third party license terms applicable
 * to your use of third party software (including open source software) that
 * may accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE,
 * INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY,
 * AND FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL MICROCHIP BE
 * LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE
 * SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS BEEN ADVISED OF THE
 * POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY
 * RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
 * THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 * \asf_license_stop
 *
 */

#ifndef _ST7565R_H_INCLUDED
#define _ST7565R_H_INCLUDED

#include <display_ctrl_mono.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \addtogroup ST7565R display driver
 *
 * \section st7565_display_rev Revision History
 * - v1.0.0 Initial Release
 *
 *@{
 */

/**
 * \brief ST7565R display controller commands
 */
#define ST7565R_CMD_DISPLAY_ON 0xAF
#define ST7565R_CMD_DISPLAY_OFF 0xAE
#define ST7565R_CMD_START_LINE_SET(line) (0x40 | (line))
#define ST7565R_CMD_PAGE_ADDRESS_SET(page) (0xB0 | (page))
#define ST7565R_CMD_COLUMN_ADDRESS_SET_MSB(column) (0x10 | (column))
#define ST7565R_CMD_COLUMN_ADDRESS_SET_LSB(column) (0x00 | (column))
#define ST7565R_CMD_ADC_NORMAL 0xA0
#define ST7565R_CMD_ADC_REVERSE 0xA1
#define ST7565R_CMD_DISPLAY_NORMAL 0xA6
#define ST7565R_CMD_DISPLAY_REVERSE 0xA7
#define ST7565R_CMD_DISPLAY_ALL_POINTS_OFF 0xA4
#define ST7565R_CMD_DISPLAY_ALL_POINTS_ON 0xA5
#define ST7565R_CMD_LCD_BIAS_1_DIV_5_DUTY33 0xA1
#define ST7565R_CMD_LCD_BIAS_1_DIV_6_DUTY33 0xA2
#define ST7565R_CMD_NORMAL_SCAN_DIRECTION 0xC0
#define ST7565R_CMD_REVERSE_SCAN_DIRECTION 0xC8
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_0 0x20
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_1 0x21
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_2 0x22
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_3 0x23
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_4 0x24
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_5 0x25
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_6 0x26
#define ST7565R_CMD_VOLTAGE_RESISTOR_RATIO_7 0x27
#define ST7565R_CMD_POWER_CTRL_ALL_ON 0x2F
#define ST7565R_CMD_SLEEP_MODE 0xAC
#define ST7565R_CMD_NORMAL_MODE 0xAD
#define ST7565R_CMD_RESET 0xE2
#define ST7565R_CMD_NOP 0xE3
#define ST7565R_CMD_ELECTRONIC_VOLUME_MODE_SET 0x81
#define ST7565R_CMD_ELECTRONIC_VOLUME(volume) (0x3F & (~volume))
#define ST7565R_CMD_BOOSTER_RATIO_SET 0xF8
#define ST7565R_CMD_BOOSTER_RATIO_2X_3X_4X 0x00
#define ST7565R_CMD_BOOSTER_RATIO_5X 0x01
#define ST7565R_CMD_BOOSTER_RATIO_6X 0x03
#define ST7565R_CMD_STATUS_READ 0x00
#define ST7565R_CMD_END 0xEE
#define ST7565R_CMD_READ_MODIFY_WRITE 0xE0

/**
 * \brief Write a command to the display controller
 *
 * This function pulls pin A0 low before writing to the controller.
 *
 * \param[in] me The pointer to display instance
 * \param[in] command The command to write
 */
void st7565r_write_command(const struct display_ctrl_mono *const me, const uint8_t command);

/**
 * \brief Write data to the display controller
 *
 * This function sets the pin A0 before writing to the controller.
 *
 * \param[in] me The pointer to display instance
 * \param[in] data The data to write
 */
void st7565r_write_data(const struct display_ctrl_mono *const me, const uint8_t data);

/**
 * \brief Read data from the display controller
 *
 * \note The controller does not support read in serial mode.
 *
 * \param[in] me The pointer to display instance
 *
 * \retval 8 bit data read from the controller
 */
uint8_t st7565r_read_data(const struct display_ctrl_mono *const me);

/**
 * \brief Perform a soft reset of the display controller
 *
 * This function resets the display controller by sending the reset command.
 *
 * \param[in] me The pointer to display instance
 */
void st7565r_soft_reset(const struct display_ctrl_mono *const me);

/**
 * \brief Perform a hard reset of the display controller
 *
 * This functions will reset the display controller by setting the reset pin
 * low.
 * \param[in] me The pointer to display instance
 */
void st7565r_hard_reset(const struct display_ctrl_mono *const me);

/**
 * \brief Enable the display sleep mode
 *
 * \param[in] me The pointer to display instance
 */
void st7565r_enable_sleep(const struct display_ctrl_mono *const me);

/**
 * \brief Disable the display sleep mode
 *
 * \param[in] me The pointer to display instance
 */
void st7565r_disable_sleep(const struct display_ctrl_mono *const me);

/**
 * \brief Set current page in display RAM
 *
 * This command is usually followed by the configuration of the column address
 * because this scheme will provide access to all locations in the display
 * RAM.
 *
 * \param[in] me The pointer to display instance
 * \param[in] address The page address to set
 */
void st7565r_set_page_address(const struct display_ctrl_mono *const me, const uint8_t address);

/**
 * \brief Set current column in display RAM
 *
 * \param[in] me The pointer to display instance
 * \param[in] address The column address to set
 */
void st7565r_set_column_address(const struct display_ctrl_mono *const me, uint8_t address);

/**
 * \brief Set the display start draw line address
 *
 * This function will set which line should be the start draw line.
 *
 * \param[in] me The pointer to display instance
 * \param[in] address The line address to set
 */
void st7565r_set_start_line_address(const struct display_ctrl_mono *const me, uint8_t address);

/**
 * \brief Turn the display display on
 *
 * This function will turn on the display.
 *
 * \param[in] me The pointer to display instance
 */
void st7565r_on(const struct display_ctrl_mono *const me);

/**
 * \brief Turn the display display off
 *
 * This function will turn off the display.
 *
 * \param[in] me The pointer to display instance
 */
void st7565r_off(const struct display_ctrl_mono *const me);

/**
 * \brief Set the display contrast level
 *
 * \warning This will set the voltage for the display, settings this value too
 * high may result in damage to the display. Hence the limit for these settings
 * must be defined in the \ref st74565r_config.h file.
 *
 * Contrast values outside the max and min values will be clipped to the defined
 * \ref ST7565R_DISPLAY_CONTRAST_MAX and \ref ST7565R_DISPLAY_CONTRAST_MIN.
 *
 * \param[in] me The pointer to display instance
 * \param[in] contrast A number between 0 and 63 where the max values is given
 *                     by the display.
 *
 * \retval contrast the contrast value written to the display controller
 */
uint8_t st7565r_set_contrast(const struct display_ctrl_mono *const me, const uint8_t contrast);

/**
 * \brief Invert all pixels on the display
 *
 * This function will invert all pixels on the display.
 *
 * \param[in] me The pointer to display instance
 */
void st7565r_display_invert_enable(const struct display_ctrl_mono *const me);

/**
 * \brief Disable invert of all pixels on the display
 *
 * This function will disable invert on all pixels on the display.
 *
 * \param[in] me The pointer to display instance
 */
void st7565r_display_invert_disable(const struct display_ctrl_mono *const me);

/**
 * \brief Sets all display pixels on
 *
 * This function can be used to test the display by setting all pixels on,
 * this will not affect the current display RAM.
 *
 * \param[in] me The pointer to display instance
 * \param[in] pixels_on if true all the display pixels are turned on,
 *                      false the display is back in normal mode displaying
 *                      what is in the display RAM
 */
void st7565r_set_all_pixels(const struct display_ctrl_mono *const me, const bool pixels_on);

/**@}*/
#ifdef __cplusplus
}
#endif

#endif /* _ST7565R_H_INCLUDED */
